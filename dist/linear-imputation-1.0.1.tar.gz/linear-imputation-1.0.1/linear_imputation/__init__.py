from .linear_imputation import Imputer, impute


__version__ = "1.0.1"